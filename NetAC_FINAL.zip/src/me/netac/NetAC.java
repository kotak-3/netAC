
package me.netac;

import cn.nukkit.plugin.PluginBase;
import me.netac.manager.*;
import me.netac.listener.*;
import me.netac.command.*;

public class NetAC extends PluginBase {
    private static NetAC instance;
    @Override public void onEnable(){
        instance = this;
        SQLiteManager.init(this);
        CheckManager.init();
        getServer().getPluginManager().registerEvents(new MoveListener(), this);
        getServer().getPluginManager().registerEvents(new CombatListener(), this);
        getServer().getPluginManager().registerEvents(new JoinQuitListener(), this);
        getServer().getCommandMap().register("netac", new NetACCommand());
        getServer().getCommandMap().register("inspect", new InspectCommand());
        getServer().getCommandMap().register("report", new ReportCommand());
        getServer().getCommandMap().register("reports", new ReportsCommand());
        getLogger().info("NetAC enabled");
    }
    public static NetAC get(){ return instance; }
}
