
package me.netac.config;
public class Config {
    public static boolean AUTO_BAN = true;
    public static int BAN_VL = 30;
    public static boolean DROP_ITEMS_ON_BAN = true;
}
