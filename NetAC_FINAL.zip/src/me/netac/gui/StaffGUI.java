
package me.netac.gui;
import cn.nukkit.*; import cn.nukkit.inventory.*; import cn.nukkit.item.*; import me.netac.manager.*;
public class StaffGUI {
    public static void open(Player p){
        Inventory inv=p.getServer().createInventory(null, InventoryType.CHEST, "§cNetAC");
        DataManager.all().forEach(d->{ if(d.globalVL>0){ Item it=Item.get(ItemID.PAPER); it.setCustomName("§c"+d.player.getName());
            it.setLore(new String[]{"§7VL: §c"+d.globalVL,"§7Chance: §e"+d.chance()+"%"}); inv.addItem(it);} });
        p.openInventory(inv);
    }
}
