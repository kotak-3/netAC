
package me.netac.data;
public class CombatData {
    private int combo=0; private long last=System.currentTimeMillis(); private int cps=0; private long lastClick=System.currentTimeMillis();
    public void hit(){ long n=System.currentTimeMillis(); if(n-last<700) combo++; else combo=1; last=n; }
    public int combo(){ return combo; } public void reset(){ combo=0; }
    public void click(){ long n=System.currentTimeMillis(); if(n-lastClick<=1000) cps++; else cps=1; lastClick=n; }
    public int cps(){ return cps; }
}
