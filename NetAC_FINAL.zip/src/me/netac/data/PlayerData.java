
package me.netac.data;
import cn.nukkit.Player; import java.util.*; import me.netac.manager.SQLiteManager;
public class PlayerData {
    public final Player player; public int globalVL=0;
    public final Map<String,Integer> checkVL=new HashMap<>();
    public final List<FlagData> flags=new ArrayList<>();
    public final CombatData combat=new CombatData();
    public final TrustData trust=new TrustData();
    public PlayerData(Player p){ player=p; }
    public void flag(String check,String info,double trustLoss){
        checkVL.put(check, checkVL.getOrDefault(check,0)+1);
        globalVL++; trust.decrease(trustLoss);
        flags.add(new FlagData(check,info,System.currentTimeMillis()));
        SQLiteManager.saveFlag(player.getName(),check,info);
    }
    public int chance(){ return (int)Math.min(100, globalVL*4 + checkVL.size()*8 + (100-trust.get())*0.6); }
}
