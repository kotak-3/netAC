
package me.netac.data;
public class FlagData {
    public final String check, info; public final long time;
    public FlagData(String c,String i,long t){check=c;info=i;time=t;}
}
