
package me.netac.data;
public class TrustData {
    private double trust = 100.0;
    public void decrease(double a){ trust=Math.max(0, trust-a); }
    public void increase(double a){ trust=Math.min(100, trust+a); }
    public double get(){ return trust; }
}
