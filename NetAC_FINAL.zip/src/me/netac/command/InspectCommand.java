
package me.netac.command;
import cn.nukkit.command.*; import cn.nukkit.*; 
public class InspectCommand extends Command {
    public InspectCommand(){ super("inspect"); }
    public boolean execute(CommandSender s,String l,String[] a){
        if(!(s instanceof Player)||a.length<1) return true;
        Player t=Server.getInstance().getPlayer(a[0]); if(t!=null) ((Player)s).teleport(t);
        return true;
    }
}
