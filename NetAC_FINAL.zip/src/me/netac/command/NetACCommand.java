
package me.netac.command;
import cn.nukkit.command.*; import cn.nukkit.Player; import me.netac.gui.StaffGUI;
public class NetACCommand extends Command {
    public NetACCommand(){ super("netac"); }
    public boolean execute(CommandSender s,String l,String[] a){
        if(s instanceof Player && s.hasPermission("netac.alerts")) StaffGUI.open((Player)s);
        return true;
    }
}
