
package me.netac.command;
import cn.nukkit.command.*; public class ReportCommand extends Command {
    public ReportCommand(){ super("report"); }
    public boolean execute(CommandSender s,String l,String[] a){ return true; }
}
