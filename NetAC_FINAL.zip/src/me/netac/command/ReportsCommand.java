
package me.netac.command;
import cn.nukkit.command.*; public class ReportsCommand extends Command {
    public ReportsCommand(){ super("reports"); }
    public boolean execute(CommandSender s,String l,String[] a){ return true; }
}
