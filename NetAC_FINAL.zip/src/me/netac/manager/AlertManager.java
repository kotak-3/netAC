
package me.netac.manager;
import cn.nukkit.*; import me.netac.data.PlayerData;
public class AlertManager {
    public static void alert(Player t, PlayerData d, String check, String info){
        for(Player p:Server.getInstance().getOnlinePlayers().values()){
            if(p.hasPermission("netac.alerts")){
                p.sendMessage("§cNetAC §7"+t.getName()+" §f"+check+" §7VL="+d.globalVL+" §c"+d.chance()+"% §8("+info+")");
            }
        }
    }
}
