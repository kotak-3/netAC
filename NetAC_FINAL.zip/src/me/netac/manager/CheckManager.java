
package me.netac.manager;
import java.util.*; import me.netac.check.*; import me.netac.check.movement.*; import me.netac.check.combat.*;
public class CheckManager {
    public static final List<Check> CHECKS=new ArrayList<>();
    public static void init(){
        CHECKS.add(new SpeedA()); CHECKS.add(new FlyA()); CHECKS.add(new MotionA());
        CHECKS.add(new KillAuraA()); CHECKS.add(new ReachA()); CHECKS.add(new AutoClickerA());
        CHECKS.add(new ComboA()); CHECKS.add(new AimA());
    }
}
