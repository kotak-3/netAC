
package me.netac.manager;
import cn.nukkit.Player; import me.netac.data.PlayerData; import me.netac.config.Config;
public class VLManager {
    public static void checkBan(Player p, PlayerData d){
        if(Config.AUTO_BAN && d.globalVL>=Config.BAN_VL){
            BanManager.autoBan(p,d);
        }
    }
}
