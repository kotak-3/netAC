
package me.netac.manager;
import java.sql.*; import me.netac.NetAC;
public class SQLiteManager {
    private static Connection c;
    public static void init(NetAC pl){
        try{
            c=DriverManager.getConnection("jdbc:sqlite:"+pl.getDataFolder()+"/data.db");
            Statement s=c.createStatement();
            s.executeUpdate("CREATE TABLE IF NOT EXISTS flags(player TEXT, checkn TEXT, info TEXT)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS bans(player TEXT, vl INT)");
        }catch(Exception e){ e.printStackTrace(); }
    }
    public static void saveFlag(String p,String c1,String i){
        try(PreparedStatement ps=c.prepareStatement("INSERT INTO flags VALUES(?,?,?)")){
            ps.setString(1,p); ps.setString(2,c1); ps.setString(3,i); ps.executeUpdate();
        }catch(Exception ignored){}
    }
    public static void saveBan(String p,int vl){
        try(PreparedStatement ps=c.prepareStatement("INSERT INTO bans VALUES(?,?)")){
            ps.setString(1,p); ps.setInt(2,vl); ps.executeUpdate();
        }catch(Exception ignored){}
    }
}
