
package me.netac.manager;
import cn.nukkit.Player; import java.util.*; import me.netac.data.PlayerData;
public class DataManager {
    private static final Map<String, PlayerData> data=new HashMap<>();
    public static PlayerData get(Player p){ return data.computeIfAbsent(p.getName(),k->new PlayerData(p)); }
    public static Collection<PlayerData> all(){ return data.values(); }
    public static void remove(Player p){ data.remove(p.getName()); }
}
