
package me.netac.manager;
import cn.nukkit.*; import cn.nukkit.item.Item; import me.netac.data.PlayerData; import me.netac.config.Config;
public class BanManager {
    public static void autoBan(Player p, PlayerData d){
        if(Config.DROP_ITEMS_ON_BAN){
            for(Item i:p.getInventory().getContents().values()) if(!i.isNull()) p.getLevel().dropItem(p.getPosition(),i);
            for(Item i:p.getArmorInventory().getContents().values()) if(!i.isNull()) p.getLevel().dropItem(p.getPosition(),i);
        }
        p.getInventory().clearAll(); p.getArmorInventory().clearAll();
        Server.getInstance().getNameBans().addBan(p.getName(),"NetAC | Cheats",null,"NetAC");
        SQLiteManager.saveBan(p.getName(), d.globalVL);
        p.kick("§cNetAC
§7Автобан за читы", false);
    }
}
