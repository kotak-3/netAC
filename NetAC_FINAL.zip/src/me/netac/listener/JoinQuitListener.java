
package me.netac.listener;
import cn.nukkit.event.*; import cn.nukkit.event.player.*; import me.netac.manager.DataManager;
public class JoinQuitListener implements Listener {
    @EventHandler public void onQuit(PlayerQuitEvent e){ DataManager.remove(e.getPlayer()); }
}
