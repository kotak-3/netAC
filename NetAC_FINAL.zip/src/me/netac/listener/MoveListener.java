
package me.netac.listener;
import cn.nukkit.event.*; import cn.nukkit.event.player.*; import me.netac.manager.*; import me.netac.data.*;
public class MoveListener implements Listener {
    @EventHandler public void onMove(PlayerMoveEvent e){
        PlayerData d=DataManager.get(e.getPlayer());
        CheckManager.CHECKS.forEach(c->c.handle(e.getPlayer(), d));
    }
}
