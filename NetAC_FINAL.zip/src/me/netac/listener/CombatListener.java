
package me.netac.listener;
import cn.nukkit.event.*; import cn.nukkit.event.entity.*; import cn.nukkit.Player; import me.netac.manager.*; import me.netac.data.*; import me.netac.check.combat.ReachA;
public class CombatListener implements Listener {
    @EventHandler public void onDamage(EntityDamageByEntityEvent e){
        if(!(e.getDamager() instanceof Player) || !(e.getEntity() instanceof Player)) return;
        Player a=(Player)e.getDamager(); Player v=(Player)e.getEntity();
        PlayerData d=DataManager.get(a);
        d.combat.hit(); d.combat.click();
        CheckManager.CHECKS.forEach(c->c.handle(a,d));
        CheckManager.CHECKS.stream().filter(c->c instanceof ReachA).forEach(c->((ReachA)c).reach(a,v,d));
    }
}
