
package me.netac.check.movement;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class SpeedA extends Check {
    private int buffer=0; private double lx,lz;
    public SpeedA(){ super("SpeedA",3.0); }
    public void handle(Player p, PlayerData d){
        double dx=p.x-lx, dz=p.z-lz; double dist=Math.sqrt(dx*dx+dz*dz);
        if(dist>0.85 && p.isOnGround()){ if(++buffer>3){ flag(p,d,"dist="+dist); buffer=0; } }
        else buffer=Math.max(0,buffer-1);
        lx=p.x; lz=p.z;
    }
}
