
package me.netac.check.movement;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class MotionA extends Check {
    private double ly;
    public MotionA(){ super("MotionA",4.0); }
    public void handle(Player p, PlayerData d){
        double dy=p.y-ly;
        if(!p.isOnGround() && dy>0.45) flag(p,d,"airY="+dy);
        ly=p.y;
    }
}
