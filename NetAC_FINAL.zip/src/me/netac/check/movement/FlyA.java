
package me.netac.check.movement;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class FlyA extends Check {
    private int air=0;
    public FlyA(){ super("FlyA",4.0); }
    public void handle(Player p, PlayerData d){
        if(!p.isOnGround()){ if(++air>6) flag(p,d,"air="+air); }
        else air=0;
    }
}
