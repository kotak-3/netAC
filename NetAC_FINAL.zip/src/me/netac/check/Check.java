
package me.netac.check;
import cn.nukkit.Player; import me.netac.data.PlayerData; import me.netac.manager.*;
public abstract class Check {
    protected final String name; protected final double trustLoss;
    protected Check(String n,double t){name=n;trustLoss=t;}
    public abstract void handle(Player p, PlayerData d);
    protected void flag(Player p, PlayerData d, String info){
        d.flag(name,info,trustLoss);
        AlertManager.alert(p,d,name,info);
        VLManager.checkBan(p,d);
    }
}
