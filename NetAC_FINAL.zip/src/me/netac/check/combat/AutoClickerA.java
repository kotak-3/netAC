
package me.netac.check.combat;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class AutoClickerA extends Check {
    public AutoClickerA(){ super("AutoClickerA",5.0); }
    public void handle(Player p, PlayerData d){
        if(d.combat.cps()>=20) flag(p,d,"CPS="+d.combat.cps());
    }
}
