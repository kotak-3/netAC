
package me.netac.check.combat;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class ReachA extends Check {
    public ReachA(){ super("ReachA",5.0); }
    public void handle(Player p, PlayerData d){}
    public void reach(Player a, Player v, PlayerData d){
        double dist=a.distance(v); if(dist>3.5) flag(a,d,"reach="+dist);
    }
}
