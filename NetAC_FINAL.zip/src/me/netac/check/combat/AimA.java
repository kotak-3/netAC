
package me.netac.check.combat;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class AimA extends Check {
    private float ly,lp;
    public AimA(){ super("AimA",5.0); }
    public void handle(Player p, PlayerData d){
        float yd=Math.abs(p.yaw-ly), pd=Math.abs(p.pitch-lp);
        if(yd>40 && pd<1.0f) flag(p,d,"yaw="+yd+" pitch="+pd);
        ly=p.yaw; lp=p.pitch;
    }
}
