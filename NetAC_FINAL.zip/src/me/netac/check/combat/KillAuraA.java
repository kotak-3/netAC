
package me.netac.check.combat;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class KillAuraA extends Check {
    public KillAuraA(){ super("KillAuraA",6.0); }
    public void handle(Player p, PlayerData d){
        if(d.combat.cps()>15) flag(p,d,"CPS="+d.combat.cps());
    }
}
