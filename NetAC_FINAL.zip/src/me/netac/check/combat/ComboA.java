
package me.netac.check.combat;
import cn.nukkit.Player; import me.netac.check.Check; import me.netac.data.PlayerData;
public class ComboA extends Check {
    public ComboA(){ super("ComboA",6.0); }
    public void handle(Player p, PlayerData d){
        if(d.combat.combo()>=8){ flag(p,d,"combo="+d.combat.combo()); d.combat.reset(); }
    }
}
