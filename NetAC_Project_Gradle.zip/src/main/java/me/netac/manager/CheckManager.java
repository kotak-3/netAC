
package me.netac.manager;

public class CheckManager {
    public static void init() {
        // register checks here
    }
}
