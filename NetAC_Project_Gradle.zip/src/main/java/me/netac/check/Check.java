
package me.netac.check;

public abstract class Check {
    protected final String name;

    protected Check(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
