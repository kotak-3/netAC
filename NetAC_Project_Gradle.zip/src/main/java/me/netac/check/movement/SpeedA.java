
package me.netac.check.movement;

import me.netac.check.Check;

public class SpeedA extends Check {
    public SpeedA() {
        super("SpeedA");
    }
}
