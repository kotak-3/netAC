
package me.netac.check.movement;

import me.netac.check.Check;

public class FlyA extends Check {
    public FlyA() {
        super("FlyA");
    }
}
