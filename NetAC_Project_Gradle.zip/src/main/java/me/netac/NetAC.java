
package me.netac;

import cn.nukkit.plugin.PluginBase;
import me.netac.manager.CheckManager;

public class NetAC extends PluginBase {

    private static NetAC instance;

    @Override
    public void onEnable() {
        instance = this;
        CheckManager.init();
        getLogger().info("NetAC enabled (Java 21 / PowerNukkitX)");
    }

    public static NetAC getInstance() {
        return instance;
    }
}
